import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UserProfileScreen extends StatefulWidget {
  const UserProfileScreen({super.key});

  @override
  _UserProfileScreenState createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  String name = '';
  int age = 0;
  String gender = 'Male';
  double weight = 0.0;
  double height = 0.0;
  String dietaryPreferences = '';
  String allergies = '';
  String healthGoals = '';

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  _loadUserData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      name = prefs.getString('name') ?? '';
      age = prefs.getInt('age') ?? 0;
      gender = prefs.getString('gender') ?? 'Male';
      weight = prefs.getDouble('weight') ?? 0.0;
      height = prefs.getDouble('height') ?? 0.0;
      dietaryPreferences = prefs.getString('dietaryPreferences') ?? '';
      allergies = prefs.getString('allergies') ?? '';
      healthGoals = prefs.getString('healthGoals') ?? '';
    });
  }

  _saveUserData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('name', name);
    prefs.setInt('age', age);
    prefs.setString('gender', gender);
    prefs.setDouble('weight', weight);
    prefs.setDouble('height', height);
    prefs.setString('dietaryPreferences', dietaryPreferences);
    prefs.setString('allergies', allergies);
    prefs.setString('healthGoals', healthGoals);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('User Profile'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: <Widget>[
              TextFormField(
                controller: TextEditingController(text: name),
                decoration: const InputDecoration(labelText: 'Name'),
                onChanged: (value) {
                  name = value;
                },
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter your name';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: TextEditingController(text: age.toString()),
                decoration: const InputDecoration(labelText: 'Age'),
                keyboardType: TextInputType.number,
                onChanged: (value) {
                  age = int.parse(value);
                },
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter your age';
                  }
                  return null;
                },
              ),
              DropdownButtonFormField<String>(
                decoration: const InputDecoration(labelText: 'Gender'),
                value: gender,
                onChanged: (String? newValue) {
                  setState(() {
                    gender = newValue!;
                  });
                },
                items: <String>['Male', 'Female', 'Other']
                    .map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),
              TextFormField(
                controller: TextEditingController(text: weight.toString()),
                decoration: const InputDecoration(labelText: 'Weight (kg)'),
                keyboardType: TextInputType.number,
                onChanged: (value) {
                  weight = double.parse(value);
                },
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter your weight';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: TextEditingController(text: height.toString()),
                decoration: const InputDecoration(labelText: 'Height (cm)'),
                keyboardType: TextInputType.number,
                onChanged: (value) {
                  height = double.parse(value);
                },
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter your height';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller:
                    TextEditingController(text: dietaryPreferences.toString()),
                decoration:
                    const InputDecoration(labelText: 'Dietary Preferences'),
                onChanged: (value) {
                  dietaryPreferences = value;
                },
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter your dietary preferences';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: TextEditingController(text: allergies.toString()),
                decoration: const InputDecoration(labelText: 'Allergies'),
                onChanged: (value) {
                  allergies = value;
                },
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter any allergies';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: TextEditingController(text: healthGoals.toString()),
                decoration: const InputDecoration(labelText: 'Health Goals'),
                onChanged: (value) {
                  healthGoals = value;
                },
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter your health goals';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _formKey.currentState!.save();
                    _saveUserData();
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                      content: Text('Profile updated successfully!'),
                    ));
                  }
                },
                child: const Text(
                  'Save',
                  style: TextStyle(
                      color: Colors.blue,
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
