import 'package:flutter/material.dart';
import 'package:health_app/auth/user_login_screen.dart';
import 'package:health_app/auth/user_sign_up_screen.dart';

import 'admin_login_screen.dart';

class RoleSelectScreen extends StatelessWidget {
  const RoleSelectScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Center(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.blueGrey[100],
              ),
              height: 200,
              width: (MediaQuery.sizeOf(context).width) - 40,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  ElevatedButton(
                    onPressed: () {
                      // Navigate to User Login Screen
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => UserLoginScreen()),
                      );
                    },
                    child: const Text(
                      'User Login',
                      style: TextStyle(
                        color: Colors.black87,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  // Add some space between the buttons
                  ElevatedButton(
                    onPressed: () {
                      // Navigate to Admin Login Screen
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const AdminLoginScreen()),
                      );
                    },
                    child: const Text(
                      'Admin Login',
                      style: TextStyle(
                        color: Colors.black87,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          InkWell(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (ctx) => const UserSignUpScreen()));
            },
            child: Container(
              decoration: BoxDecoration(
                  color: Colors.lightGreen[100],
                  borderRadius: BorderRadius.circular(10)),
              margin: const EdgeInsets.only(right: 20.0),
              padding: const EdgeInsets.all(10),
              child: const Text(
                'User Sign up',
                style: TextStyle(
                  color: Colors.black87,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
