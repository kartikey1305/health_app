import 'dart:convert';

import 'package:flutter/services.dart';

import 'model/food_model.dart';

class FoodDatabase {
  List<FoodModel> _foods = [];

  FoodDatabase() {
    // Load food data from a JSON file or API
    _loadFoodData();
  }

  void _loadFoodData() async {
    final jsonString = await rootBundle.loadString('assets/food.json');
    final jsonData = jsonDecode(jsonString);
    _foods = jsonData
        .map<FoodModel>((jsonFood) => FoodModel.fromJson(jsonFood))
        .toList();
  }

  List<FoodModel> searchFoods(String query) {
    return _foods
        .where((food) =>
            food.foodName!.toLowerCase().contains(query.toLowerCase()))
        .toList();
  }

  List<FoodModel> filterFoodsByNutrient(
      String nutrient, double minValue, double maxValue) {
    return _foods
        .where((food) =>
            food.nutrients != null &&
            food.nutrients!.carbohydrates! >= minValue &&
            food.nutrients!.carbohydrates! <= maxValue)
        .toList();
  }
}
