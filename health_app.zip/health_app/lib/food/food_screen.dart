import 'package:flutter/material.dart';

import 'food_database.dart';
import 'model/food_model.dart';

class FoodSearchPage extends StatefulWidget {
  const FoodSearchPage({super.key});

  @override
  _FoodSearchPageState createState() => _FoodSearchPageState();
}

class _FoodSearchPageState extends State<FoodSearchPage> {
  final FoodDatabase _foodDatabase = FoodDatabase();
  final TextEditingController _searchController = TextEditingController();
  List<FoodModel> _searchResults = [];
  String dropValue = 'calories';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        title: const Text('Food Search'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            TextField(
              controller: _searchController,
              decoration: const InputDecoration(
                labelText: 'Search for a food',
                border: OutlineInputBorder(),
              ),
              onChanged: (query) {
                setState(() {
                  _searchResults = _foodDatabase.searchFoods(query);
                });
              },
            ),
            const SizedBox(height: 20),
            DropdownButton<String>(
              value: dropValue,
              onChanged: (nutrient) {
                setState(() {
                  dropValue = nutrient!;
                  _searchResults =
                      _foodDatabase.filterFoodsByNutrient(nutrient!, 0, 1000);
                });
              },
              items: const [
                DropdownMenuItem(value: 'calories', child: Text('Calories')),
                DropdownMenuItem(value: 'protein', child: Text('Protein')),
                DropdownMenuItem(value: 'fat', child: Text('Fat')),
                // Add more nutrients as needed
              ],
            ),
            const SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: _searchResults.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(_searchResults[index].foodName!),
                    subtitle: Text(_searchResults[index].foodType!),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
