class FoodModel {
  int? id;
  String? foodName;
  String? foodType;
  int? calories;
  Nutrients? nutrients;

  FoodModel(
      {this.id, this.foodName, this.foodType, this.calories, this.nutrients});

  FoodModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    foodName = json['foodName'];
    foodType = json['foodType'];
    calories = json['calories'];
    nutrients = json['nutrients'] != null
        ? Nutrients.fromJson(json['nutrients'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['foodName'] = foodName;
    data['foodType'] = foodType;
    data['calories'] = calories;
    if (nutrients != null) {
      data['nutrients'] = nutrients!.toJson();
    }
    return data;
  }
}

class Nutrients {
  var protein;
  var fat;
  var carbohydrates;

  Nutrients({this.protein, this.fat, this.carbohydrates});

  Nutrients.fromJson(Map<String, dynamic> json) {
    protein = json['protein']??0;
    fat = json['fat'];
    carbohydrates = json['carbohydrates'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['protein'] = protein;
    data['fat'] = fat;
    data['carbohydrates'] = carbohydrates;
    return data;
  }
}
