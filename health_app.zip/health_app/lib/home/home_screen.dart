import 'package:flutter/material.dart';
import 'package:health_app/auth/role_select_screen.dart';
import 'package:health_app/food/food_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../profile/profile_screen.dart';
import 'personalized_details_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 100),
            FutureBuilder<Map<String, dynamic>>(
              future: getData(),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  return ListTile(
                    leading: CircleAvatar(
                      radius: 25,
                      child: Text(snapshot.data?['name']
                              .toString()
                              .split(' ')
                              .first
                              .substring(0, 1) ??
                          ''),
                    ),
                    title: Text(
                      snapshot.data?['name'] ?? '',
                      style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                          color: Colors.black),
                    ),
                    subtitle: Text(
                      snapshot.data?['email'] ?? '',
                      style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: Colors.black),
                    ),
                  );
                } else {
                  return const SizedBox.shrink();
                }
              },
            ),
            ListTile(
              onTap: () async {
                SharedPreferences sharedPreference =
                    await SharedPreferences.getInstance();
                final data =
                    await sharedPreference.setBool('isLoggedIn', false);
                if (data) {
                  Navigator.of(context).pushAndRemoveUntil(
                      MaterialPageRoute(
                          builder: (context) => const RoleSelectScreen()),
                      (Route<dynamic> route) => false);
                }
              },
              title: const Text("Logout"),
              leading: const Icon(Icons.logout),
            )
          ],
        ),
      ),
      appBar: AppBar(
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (ctx) => const UserProfileScreen()));
            },
            icon: const Icon(Icons.supervised_user_circle),
          )
        ],
      ),
      body: FutureBuilder<Map<String, dynamic>>(
          future: getData(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              if (!snapshot.data!['isAdminLogin']) {
                return const PersonalizedPlanScreen();
              } else {
                return const FoodSearchPage();
              }
            } else {
              return const PersonalizedPlanScreen();
            }
          }),
    );
  }

  Future<Map<String, dynamic>> getData() async {
    SharedPreferences sp = await SharedPreferences.getInstance();
    Map<String, dynamic> data = {};
    data['email'] = sp.getString('email') ?? '';
    data['name'] = sp.getString('name') ?? '';
    data['isAdminLogin'] = sp.getBool('isAdminLogin') ?? false;
    return data;
  }
}
