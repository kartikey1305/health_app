import 'package:flutter/material.dart';

class PersonalizedPlanScreen extends StatelessWidget {
  const PersonalizedPlanScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        title: const Text('Personalized Details Plan'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _buildSectionTitle('Daily Meal Suggestions'),
            _buildMealSuggestionsList([
              Meal('Breakfast',
                  'Healthy omelette with spinach and whole grain toast'),
              Meal('Lunch', 'Grilled chicken salad with avocado and quinoa'),
              Meal('Snack', 'Greek yogurt with berries and a sprinkle of nuts'),
              Meal('Dinner',
                  'Baked salmon with steamed broccoli and brown rice'),
              Meal('Dessert', 'Fresh fruit salad with a drizzle of honey'),
            ]),
            _buildSectionTitle('Weekly Meal Suggestions'),
            _buildMealSuggestionsList([
              Meal('Monday', 'Vegetarian chili with cornbread'),
              Meal('Tuesday',
                  'Stir-fried tofu with vegetables and rice noodles'),
              Meal('Wednesday', 'Pasta primavera with a side of garlic bread'),
              Meal('Thursday',
                  'Turkey meatballs in marinara sauce over zucchini noodles'),
              Meal('Friday',
                  'Shrimp tacos with mango salsa and cilantro lime rice'),
            ]),
            _buildSectionTitle('Monthly Meal Suggestions'),
            _buildMealSuggestionsList([
              Meal('Week 1',
                  'Healthy meal prep for the week: grilled chicken, roasted vegetables, and quinoa'),
              Meal('Week 2',
                  'Homemade sushi rolls with fresh fish and vegetables'),
              Meal('Week 3',
                  'Buddha bowl with mixed greens, roasted chickpeas, and tahini dressing'),
              Meal('Week 4',
                  'Vegetable curry with coconut milk and jasmine rice'),
            ]),
            const SizedBox(height: 20.0),
            const Divider(),
            const SizedBox(height: 20.0),
            _buildSectionTitle('Nutrient Breakdown'),
            _buildNutrientBreakdown(),
            const SizedBox(height: 100.0),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Text(
        title,
        style: const TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget _buildMealSuggestionsList(List<Meal> meals) {
    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: meals.length,
      itemBuilder: (context, index) {
        return Card(
          elevation: 2.0,
          margin: const EdgeInsets.symmetric(vertical: 8.0),
          child: ListTile(
            leading: const CircleAvatar(
              child: Icon(Icons.restaurant_menu),
            ),
            title: Text(meals[index].name),
            subtitle: Text(meals[index].description),
            onTap: () {
              // Handle tapping on meal suggestion if needed
            },
          ),
        );
      },
    );
  }

  Widget _buildNutrientBreakdown() {
    // Placeholder for nutrient breakdown UI (to be implemented)
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
          color: Colors.blue[200], borderRadius: BorderRadius.circular(20)),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('Calories: 2000 kcal',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          Text('Protein:   100g',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          Text('Fat:           50g',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          Text('Carbs:      250g',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          Text('Vitamins: A, B, C',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          Text('Minerals: Iron, Calcium',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}

class Meal {
  final String name;
  final String description;

  Meal(this.name, this.description);
}
